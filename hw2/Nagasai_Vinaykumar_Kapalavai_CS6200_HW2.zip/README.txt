1. For Task1 Obtaining directed web graphs:
   The input file of 1000 links in task1_input.txt and the source file is task1,
   one can execute the file by ./task1. The output can be seen as task1_output.txt.

2. For Task2, Implementing and running pagerank
   a:Graph-1:
     The generation of graph and page rank implementation can be observed by running the script task2,(./task2), initially it prompts to specify the input file, which is task2g_a.txt, then it asks for the option
     from the user, if one enters top50, we get the top 50 page ranks of the web pages and if nothing is given(By simply givin enter button), it will just display the output file which consists of perplexity values
     fro the graph.
   b:Graph-2:
     The generation of graph and page rank implementation can be observed by running the script task2,(./task2), initially it prompts to specify the input file, which is task2g_b.txt, then it asks for the option
     from the user, if one enters top50, we get the top 50 page ranks of the web pages and if nothing is given(By simply givin enter button), it will just display the output file which consists of perplexity values
     fro the graph.
   c:Graph-3:
     For the graph3, the input file is task2g_c.txt and the executable file is ./task2g_c , it will compute the page rank.
