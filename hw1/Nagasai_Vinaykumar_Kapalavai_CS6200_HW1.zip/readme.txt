The
1. Task-1 : This can be verified by running the file combinedtask(./combinedtask or python combinedtask), which prompts to enter the url. The url that need to be entered is "https://en.wikipedia.org/wiki/Sustainable_energy"
            Then it prompts to enter the keyword from the user, just give enter (which means we are not giving any keyword).
            Finally it print's the corresponding crawled links, current depth, the no.of links it crawled and writes the crawled links into a seperate file.

2. Task-2 : This can be verified by running the same file combinedtask, which prompts to enter the url. The url that need to be entered is "https://en.wikipedia.org/wiki/Sustainable_energy" 
            and further asks the seed from the user, which is "solar".
            Finally it print's the corresponding crawled links , current depth, the no.of links it crawled in a bfs manner and writes the crawled links into a seperate file.
            
   Task-2 : This can be verified by running the file task2_dfs(./task2_dfs or python task2_dfs), which prompts to enter the url. The url that need to be entered is "https://en.wikipedia.org/wiki/Sustainable_energy"
            and further asks the seed from user, which is "solar".
            Finally it print's the corresponding crawled links , current depth, the no.of links it crawled in a dfs manner and writes the crawled links into a seperate file.

3. Task-3 : This can be verified by running the file combinedtask, which prompts to enter the url. The url that need to be entered is "https://en.wikipedia.org/wiki/Solar_power"
            When it prompts to enter keyword, just give enter (Which means we are not giving any keyword).
            Finally it print's the corresponding crawled links , current depth, the no.of links it crawled and writes the crawled links into a seperate file.   
